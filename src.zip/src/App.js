import Employee from './componenets/Employee';
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  return (
    <div className="App">
      <Employee></Employee>
    </div>
  );
}

export default App;
